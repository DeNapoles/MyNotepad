﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Window;

namespace MyNotePad
{
    public partial class Form1 : Form
    {
        #region Variaveis

        private string ficheiro = ""; //irá conter o nome do ficheiro
        public Form1()
        {
            InitializeComponent();
        }

        #endregion

        #region Procedimento Verificar Alterações

        private void VerificarAlteracoes()
        {
            if (rbTexto.Modified == true)     //O método Modified permite registar se ocorreram alterações ao conteúdo do objeto RichTextBox
            {
                DialogResult resposta = MessageBox.Show("Deseja guardar o texto atual?", "Atenção", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (resposta == DialogResult.Yes)
                {
                    if (ficheiro != "")
                    {
                        rbTexto.SaveFile(ficheiro);     //Atualização do ficheiro
                        rbTexto.Modified = false;
                    }
                    else
                    {
                        GuardarFicheiro();    //Novo ficheiro
                    }
                }
            }
        }
        #endregion

        #region Procedimento Guardar Ficheiro

        private void GuardarFicheiro()
        {
            saveFileDialog1.Filter = "Ficheiro RTF | *.rtf | Ficheiro TXT | *.txt";   //É aberto o ficheiro selecionado.

            saveFileDialog1.FileName = "";

            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                ficheiro = saveFileDialog1.FileName;    //Gravação do conteúdo em ficheiro.
                rbTexto.SaveFile(ficheiro);
                rbTexto.Modified = false;
            }
        }

        #endregion

        #region Menu Ficheiro

        private void toolStripSplitButton1_ButtonClick(object sender, EventArgs e)
        {

        }

        private void menuFicheiroNovo_Click(object sender, EventArgs e)
        {
            VerificarAlteracoes(); //entes de criar um novo documento, verifica se existem alterações e se pretende guardá-las.

            rbTexto.ResetText();
            rbTexto.Modified = false;
            ficheiro = null;
        }

        private void menuFicheiroAbrir_Click(object sender, EventArgs e)
        {
            VerificarAlteracoes();     //Antes de criar um novo documento verificar se existem alterações e se pretende guardá - las.


            openFileDialog1.Filter = "Ficheiros RTF|  *.rtf | Ficheiros TXT | *.TXT | Todos | *.*";  //Configuração da caixa de diálogo de abrir.
            openFileDialog1.FileName = "";

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                ficheiro = openFileDialog1.FileName;  //É aberto o ficheiro selecionado.
                rbTexto.LoadFile(ficheiro);
                rbTexto.Modified = false;
            }
        }

        private void menuFicheiroGuardar_Click(object sender, EventArgs e)
        {
            if (ficheiro != "")
            {
                rbTexto.SaveFile(ficheiro);
                rbTexto.Modified = false;
            }
            else
            {
                GuardarFicheiro();
            }
        }

        private void menuFicheiroSair_Click(object sender, EventArgs e)
        {
            DialogResult resposta = MessageBox.Show("Deseja sair da aplicação?", "Aviso", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (resposta == DialogResult.Yes)
            {
                VerificarAlteracoes();
                Application.Exit();
            }
        }

        #endregion

        #region Menu Editar


        private void menuEditarCortar_Click(object sender, EventArgs e)
        {
            rbTexto.Cut();   //O método Cut permite cortar o texto selecionado.
        }
        private void menuEditarCopiar_Click(object sender, EventArgs e)
        {
            rbTexto.Copy();   //O método Copy permite copiar o texto selecionado para a memória RAM do computador.
        }
        private void menuEditarColar_Click(object sender, EventArgs e)
        {
            rbTexto.Paste();  //O método Paste permite copiar o texto da memória RAM do computador para a posição do cursor.
        }
        private void menuEditarSelecionar_Click(object sender, EventArgs e)
        {
            rbTexto.SelectAll();   //O método SelectAll permite selecionar todo o texto do objeto RichTextBox.
        }
        private void menuEditarProcurar_Click(object sender, EventArgs e)
        {
            string txtProcura = Interaction.InputBox("Digite o que procura:", "Procurar", "", 150, 200); //Guardar o texto a procurar usando o InputBox.

            int resultado = rbTexto.Find(txtProcura);   //O método Find permite procurar no objeto RichTextBox a palavra digitada pelo utilizador

            if (resultado == -1)
                MessageBox.Show("Aviso", "Não foi encontrada a sua procura.", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);  //Se a palavra não for encontrada o método Find devolve - 1.
        }

        #endregion

        #region Menu Formatar

        #region Letras
        private void menuFormatarLetra_Click(object sender, EventArgs e)
        {
            if (rbTexto.SelectionFont != null)
            {
                fontDialog1.Font = rbTexto.SelectionFont; //Configuração da caixa de diálogo do tipo de letra com o tipo de letra do texto.
            }
            else
            {
                fontDialog1.Font = null;
            }
            fontDialog1.ShowDialog();
            rbTexto.SelectionFont = fontDialog1.Font;   //Apresentação da caixa de diálogo do tipo de letra e, após a alteração pelo utilizador, é aplicada ao objeton RichTextBox.
        }

        #endregion

        #region Cores
        private void menuFormatarCoresLetras_Click(object sender, EventArgs e)
        {
            colorDialog1.ShowDialog();
            rbTexto.SelectionColor = colorDialog1.Color;
        }
        private void menuFormatarCoresFundo_Click(object sender, EventArgs e)
        {
            colorDialog1.ShowDialog();
            rbTexto.SelectionBackColor = colorDialog1.Color;
        }
        #endregion

        #region Menu Alinhamento
        private void menuFormatarAlinhamentoEsquerda_Click(object sender, EventArgs e)
        {
            rbTexto.SelectionAlignment = HorizontalAlignment.Left;
        }
        private void menuFormatarAlinhamentoCentro_Click(object sender, EventArgs e)
        {
            rbTexto.SelectionAlignment = HorizontalAlignment.Center;
        }
        private void menuFormatarAlinhamentoDireita_Click(object sender, EventArgs e)
        {
            rbTexto.SelectionAlignment = HorizontalAlignment.Right;
        }

        #endregion

        #endregion


    }
}
